import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const asset = (...segments) => path.join(__dirname, "storage", "temp", ...segments);

export default {
  usePairingCode : true,

  //nombor bot klo malay  60 klo indo 62 dan tidak pake + , jarak dll

  botNumber : "6012345678", //nomornya klo bisa jgn sama dgn owner nnti beli nokos biar nomor kalian ga diban
                                                                                                                          
  bot: {

   nameBot : "Mirai MD", //pasang nama klian sendiri atau nama yg keren
   Developers : "wa.me60163246722", // gtw sih untuk wa gitu klo mw tele t.me mungkin research aja nnti
  },

  Owner: {
    ownerNumber : ["6012345678"], //nomor lu bukan untuk bot yaa
  }, 

  isOwner(value) {
    const needle = String(value ?? "").replace(/[^0-9]/g, "");
    const list = Array.isArray(this.owner?.number) ? this.owner.number : [this.owner?.number];
    return !!needle && list.filter(Boolean).some((item) => String(item).replace(/[^0-9]/g, "") === needle);
  },                                                                               

  command : {
    prefix : ".",
    caseSensitive : false,
  },

    
} 