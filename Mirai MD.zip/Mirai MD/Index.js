import makeWASocket, {
    Browsers,
    DisconnectReason,
    useMultiFileAuthState,
} from "@whiskeysockets/baileys";
import pino from "pino";
import fs from "fs";
import https from "https";
import http from "http";
import os from "os";

function pingServer(url) {
    return new Promise((resolve) => {
        const start = Date.now();
        const req = https.request(url, { method: "HEAD" }, (res) => {
            res.resume();
            resolve(Date.now() - start);
        });
        req.on("error", () => {
            resolve(Date.now() - start);
        });
        req.setTimeout(5000, () => {
            req.destroy();
            resolve(Date.now() - start);
        });
        req.end();
    });
}

function getNetworkInfo() {
    return new Promise((resolve) => {
        http.get("http://ip-api.com/json/", (res) => {
            let data = "";
            res.on("data", (chunk) => data += chunk);
            res.on("end", () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.status === "success") {
                        resolve({
                            isp: parsed.isp || parsed.org || "Unknown ISP",
                            city: parsed.city || "Unknown City",
                            country: parsed.country || "Unknown Country",
                            region: parsed.regionName || ""
                        });
                    } else {
                        resolve(null);
                    }
                } catch {
                    resolve(null);
                }
            });
        }).on("error", () => {
            resolve(null);
        });
    });
}


async function konekWA() {
    console.log("Memulai koneksi WhatsApp...");
    const { state, saveCreds } = await useMultiFileAuthState("session");

    const sock = makeWASocket({
        auth: state,
        browser: Browsers.ubuntu("Chrome"),
        logger: pino({ level: "silent" })
    });

    sock.ev.on("creds.update", saveCreds);

    let pairingCodeRequested = false;

    // Handle connection updates
    sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (connection) {
            console.log("Status Koneksi:", connection);
        }

        // Request pairing code when QR/pairing challenge is ready
        if (qr && !state.creds.registered && !pairingCodeRequested) {
            pairingCodeRequested = true;
            try {
                console.log("Generating pairing code...");
                // Delay to ensure the socket handshake is fully stable
                await new Promise((resolve) => setTimeout(resolve, 2000));
                
                const phoneNumber = "nomor_kamu";
                const code = await sock.requestPairingCode(phoneNumber);
                console.log(`\n====================================`);
                console.log(`PAIRING CODE ANDA: ${code}`);
                console.log(`Masukkan kode ini di WhatsApp -> Perangkat Tertaut -> Tautkan dengan nomor telepon`);
                console.log(`====================================\n`);
            } catch (err) {
                console.error("Gagal mendapatkan pairing code:", err.message || err);
                pairingCodeRequested = false;
            }
        }

        if (connection === "open") {
            console.log("WhatsApp terhubung sukses!");
        }

        if (connection === "close") {
            const error = lastDisconnect?.error;
            const statusCode = error?.output?.statusCode;
            console.log(`Koneksi terputus. Status: ${statusCode}. Reason: ${error?.message}`);

            if (statusCode === DisconnectReason.loggedOut) {
                console.log("Session terdeteksi logged out. Membersihkan folder session...");
                try {
                    fs.rmSync("session", { recursive: true, force: true });
                } catch (err) {
                    console.error("Gagal menghapus folder session:", err.message);
                }
                console.log("Menghubungkan kembali sebagai sesi baru dalam 5 detik...");
                setTimeout(() => konekWA(), 5000);
            } else {
                console.log("Menghubungkan kembali dalam 5 detik...");
                setTimeout(() => konekWA(), 5000);
            }
        }
    });

    // Handle incoming messages
    sock.ev.on("messages.upsert", async (chatUpdate) => {
        try {
            const msg = chatUpdate.messages[0];
            if (!msg.message) return;

            // Get message body/text
            const body = msg.message.conversation || 
                         msg.message.extendedTextMessage?.text || 
                         msg.message.imageMessage?.caption || 
                         msg.message.videoMessage?.caption || 
                         "";

            // Anti-Virtex: Mengabaikan pesan yang terlalu panjang untuk menghindari overload
            if (body.length > 5000) {
                console.log(`Mengabaikan pesan terlalu panjang (${body.length} karakter) demi kestabilan.`);
                return;
            }

            const command = body.trim().toLowerCase();

            if (command === ".ping") {
                console.log("Menerima command .ping");
                
                // Kirim status awal
                await sock.sendMessage(msg.key.remoteJid, { text: "Menghitung ping & mengumpulkan informasi server..." }, { quoted: msg });
                
                // Fetch network info and measure 1 ping concurrently
                const [netInfo, ping] = await Promise.all([
                    getNetworkInfo(),
                    pingServer("https://web.whatsapp.com")
                ]);
                
                const getRating = (ms) => {
                    if (ms < 50) return "EXCELLENT ðŸŸ¢";
                    if (ms < 100) return "GOOD ðŸŸ¡";
                    if (ms < 200) return "NORMAL ðŸŸ ";
                    return "SLOW ðŸ”´";
                };

                const rating = getRating(ping);
                
                // System stats
                const platform = os.platform();
                const arch = os.arch();
                const totalMem = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(1); // GB
                const freeMem = (os.freemem() / (1024 * 1024 * 1024)).toFixed(1); // GB
                const usedMem = (totalMem - freeMem).toFixed(1);
                
                // Format response
                const ispName = netInfo?.isp || "Unknown ISP";
                const location = netInfo ? `${netInfo.city}, ${netInfo.country}` : "Unknown Location";

                const responseText = `*ðŸš€ [ SPEEDTEST PING & SERVER INFO ] ðŸš€*\n` +
                                     `â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€\n` +
                                     `â€¢ Ping Latensi: *âš¡ ${ping} ms* â”€â”€ ã€Ž ${rating} ã€\n` +
                                     `â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€\n` +
                                     `*ðŸ–¥ï¸ INFORMASI SERVER:*\n` +
                                     `â€¢ Provider / ISP: *${ispName}*\n` +
                                     `â€¢ Lokasi Server: *${location}*\n` +
                                     `â€¢ OS Platform: *${platform} (${arch})*\n` +
                                     `â€¢ RAM Usage: *${usedMem} GB / ${totalMem} GB* (Free: ${freeMem} GB)\n` +
                                     `â€¢ Status Sistem: *ACTIVE & SECURE* ðŸ”’`;
                
                await sock.sendMessage(msg.key.remoteJid, { text: responseText }, { quoted: msg });
            }
        } catch (err) {
            console.error("Error handling message:", err);
        }
    });
}

// Proteksi global agar program bot tidak mati jika terjadi error tak terduga atau payload crash
process.on("uncaughtException", (err) => {
    console.error("Mencegah Crash - Uncaught Exception:", err.message || err);
});

process.on("unhandledRejection", (reason, promise) => {
    console.error("Mencegah Crash - Unhandled Rejection:", reason);
});

konekWA();